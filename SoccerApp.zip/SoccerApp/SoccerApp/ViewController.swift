//
//  ViewController.swift
//  SoccerApp
//
//  Created by daffa ahnaf on 18/12/20.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var TimA: UIImageView!
    @IBOutlet weak var TimB: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func StartButton(_ sender: UIButton) {
        let club = [ #imageLiteral(resourceName: "Group 3"),#imageLiteral(resourceName: "Group 5"),#imageLiteral(resourceName: "Group 2"),#imageLiteral(resourceName: "Group 9"),#imageLiteral(resourceName: "Group 7"),#imageLiteral(resourceName: "Group 8"),#imageLiteral(resourceName: "Group 6"),#imageLiteral(resourceName: "Group 4") ]
        
        TimA.image = club.randomElement()
        TimB.image = club.randomElement()
    }
    
}

